import java.applet.Applet;
import java.awt.Graphics;

public class MyApplet extends Applet {
	private String param1, param2;
	
	public void init() {
		param1 = this.getParameter("param1");
		param2 = this.getParameter("param2");
	}
	public void start() {}
	public void paint(Graphics g) {
		g.drawString("param1 = " + param1, 100, 80);
		g.drawString("param2 = " + param2, 100, 120);
	}
	public void stop() {}
	public void destroy() {}
}
