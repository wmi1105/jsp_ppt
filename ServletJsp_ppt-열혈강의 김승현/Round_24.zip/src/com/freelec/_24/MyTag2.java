package com.freelec._24;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

public class MyTag2 extends BodyTagSupport {
	private JspWriter out;
	private String cols;
	private String rows;
	public String getCols() {
		return cols;
	}
	public void setCols(String cols) {
		this.cols = cols;
	}
	public String getRows() {
		return rows;
	}
	public void setRows(String rows) {
		this.rows = rows;
	}
	
	public JspWriter getPreviousOut() {
		return pageContext.getOut();
	}
	//<ksh:hello cols="3" rows="2">�����</ksh:hello>
	public int doStartTag() throws JspException {
		try {
			out = getPreviousOut();
		}catch(Exception ex) {}
		return BodyTagSupport.EVAL_BODY_BUFFERED;
	}
	public int doAfterBody() throws JspException {
		int col = 1;
		int row = 1;
		try {
			col = Integer.parseInt(this.cols);
			row = Integer.parseInt(this.rows);
		}catch(Exception ex) {}
		String data = bodyContent.getString();
		StringBuffer buffer = new StringBuffer();
		buffer.append("<table width='300' border='1'>\n");
		for(int i = 0; i < row; ++i) {
			buffer.append("<tr>\n");
			for(int j = 0; j < col; ++j) {
				buffer.append("<td>" + data + "</td>\n");
			}
			buffer.append("</tr>\n");
		}
		buffer.append("</table>\n");
		try {
			out.println(buffer.toString());
			out.flush();
		}catch(Exception ex) {}
		return BodyTagSupport.EVAL_PAGE;
	}
	public int doEndTag() throws JspException {
		return BodyTagSupport.EVAL_PAGE;
	}
}




