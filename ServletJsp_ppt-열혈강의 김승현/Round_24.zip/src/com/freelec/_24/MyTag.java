package com.freelec._24;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public class MyTag implements Tag {
	private PageContext pageContext;
	private Tag parent;
	
	@Override
	public int doEndTag() throws JspException {
		// TODO Auto-generated method stub
		
		JspWriter out = pageContext.getOut();
		try {
			out.println("Hello My Tag!!!!");
		}catch(Exception ex) {}
		
		return Tag.EVAL_PAGE;
	}
	//<a>fdsaf</a>fjdlksafjlkdjflkdsa
	@Override
	public int doStartTag() throws JspException {
		// TODO Auto-generated method stub
		return Tag.SKIP_BODY;
	}

	@Override
	public Tag getParent() {
		// TODO Auto-generated method stub
		return this.parent;
	}

	@Override
	public void release() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPageContext(PageContext arg0) {
		// TODO Auto-generated method stub
		this.pageContext = arg0;
	}

	@Override
	public void setParent(Tag arg0) {
		// TODO Auto-generated method stub
		this.parent = arg0;
	}

}
